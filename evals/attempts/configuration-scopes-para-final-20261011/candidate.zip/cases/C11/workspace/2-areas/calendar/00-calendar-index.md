---
type: moc
created: 2026-09-20
document-maturity: draft
---

# Calendar

Meetings.

[Planning series snapshot](we-2026.09.27/2026.09.21-planning-series.ics) ? weekly-11@example.test, whole native series.

[Occurrence exception snapshot](we-2026.10.04/2026.09.29-planning-exception.ics) ? recurrence identity 20260928T150000Z; occurrence starts September 29. Live state not checked.
