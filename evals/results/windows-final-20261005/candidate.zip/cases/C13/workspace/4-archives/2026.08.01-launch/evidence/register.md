---
type: note
created: 2026-09-20
document-maturity: draft
---

# Evidence

[Agreement](contracts/signed.txt)
