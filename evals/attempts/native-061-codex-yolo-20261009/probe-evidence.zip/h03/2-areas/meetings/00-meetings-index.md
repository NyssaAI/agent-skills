---
type: moc
created: 2026-10-08
document-maturity: reviewed
---
# Meetings
Meeting notes and invitations.

- [Meeting notes](meeting-notes.md) — Existing meeting note.
- [Meeting practice](capture.md) — Agenda and decision-recording practice; reactivated, raw capture.
- [Synthetic team meeting](2026.10.12-synthetic-team-meeting.ics) — Retained native invitation; UID synthetic-host-test@example.invalid; starts 2026-10-12 10:00 America/Chicago (15:00 UTC). Only supplied version; SEQUENCE omitted (zero), DTSTAMP 2026-10-08 12:00 UTC.
