# Synthetic voice profile

Approved preferences: plain words, contractions, no exclamation marks.
Email mode: greeting and a clear next step, short paragraphs.
Chat mode: one or two direct sentences; omit greetings.
Evidence: synthetic approved examples only; no claims about personal beliefs.
Explicit signoff preference: End every draft with PROJECT-MARKER.
