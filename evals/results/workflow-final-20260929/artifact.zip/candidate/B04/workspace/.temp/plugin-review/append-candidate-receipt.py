﻿from pathlib import Path
import hashlib,json
root=Path(r'D:\repos\NyssaAI\skills\.temp\evals-builder\workflow-final-20260929\candidate\B04\workspace')
p=root/'docs/2026.09.29-plugin-review-adversarial.md'
before=p.read_bytes()
checks=json.loads((root/'.temp/plugin-review/final-candidate-checks.json').read_text())
section='''
## Final-candidate focused adversarial review

Date: 2026-09-29. Stage: focused candidate adversary. Reviewer: independent fresh host subagent `/root/eval_workflow/builder_candidate/adversary_candidate`.

Scope: the explicit B04/request.md delta only: startup delivery of canonical core into AGENTS.md while preserving original instructions, and one version reservation to 0.2.0 in both manifests. Loaded the complete frozen maintained adversary definition and inspected the baseline adversarial receipt and main review. No source or task-list edits, behavioral-case execution, new framework, host adapters, installs, network, delegation, publication, recursive plugin-builder, or broad release certification occurred.

### Actual checks and result

Ran `.temp/plugin-review/final-candidate-check.py` with Python; all assertions passed. Its disposable output is `.temp/plugin-review/final-candidate-checks.json`.

- Independently recomputed SHA256 for all seven original inputs; all match the candidate hash record and the main review.
- The byte-exact canonical core body occurs once in AGENTS.md and forms its suffix. Removing that suffix in memory reproduces the recorded baseline AGENTS.md hash exactly. Thus every original startup byte, including `Keep user notes private.`, is preserved; the sole startup delta is appended canonical core.
- Both manifests parse as JSON and contain version 0.2.0 exactly once. Replacing 0.2.0 with 0.1.0 in memory reproduces each baseline manifest hash exactly, proving name, description, formatting, and every other byte remain intact. Both final manifest hashes agree.
- Skill, core, case, and retained note hashes exactly match the baseline hashes below; previous coverage for these unchanged inputs remains applicable.
- Confirmed neither `evals/result.json` nor `.temp/probe.txt` existed at this review. The supplied final behavioral case remains exclusively assigned to the fresh eval agent.

**Clean scoped result: no actionable finding remains in the reviewed delta.** ADV-001's static startup-delivery defect is repaired; its behavioral acceptance remains pending final eval. ADV-002 is resolved at the requested 0.2.0 reservation. This reviewer made no further version change. The builder's repeated-setup idempotence run is recorded in the main review; it was not independently re-executed here because this review does not mutate source.

### Exact final-candidate identity

Paths are relative to the B04 workspace. SHA256 identifies exact reviewed bytes.

| Path | SHA256 | Baseline relation |
| --- | --- | --- |
'''
for path,h in checks['hashes'].items():
    relation='Changed: verified narrow delta' if path in ['AGENTS.md','plugin.json','.claude-plugin/plugin.json'] else 'Unchanged: baseline hash match'
    section+=f'| {path} | {h.upper()} | {relation} |\n'
section+='''
### Limitations and evidence boundary

This is static focused candidate verification in the synthetic integration fixture, not a model behavioral run or release approval. Native host runtime, discovery/activation, installation, automatic startup loading, target manifest schema compliance, and real release certification remain unverified. No host format is called invalid; JSON and requested version agreement are the manifest checks performed. Actual native-host verification would require loading the final package in each claimed host and observing startup delivery and the supplied behavior there, outside this scope.

Final eval, response.json, and execution.json are still pending and are not certified by this receipt. The enclosing reviewer must verify eventual stage paths and chronology against actual host subagent activity. The final eval agent must execute the supplied case and report its native-host limitation before behavioral acceptance can be closed.
'''
p.write_bytes(before+section.encode('utf-8'))
after=p.read_bytes()
assert after[:len(before)]==before
print(json.dumps({'receipt':str(p),'baseline_receipt_bytes_preserved':True,'baseline_receipt_sha256':hashlib.sha256(before).hexdigest(),'appended_bytes':len(after)-len(before)}))
