---
type: note
created: 2026-09-20
status: raw
---

# Escalation procedure

Use the incident queue.

Required by audit A-17. Mira owns this procedure, which applies to vendor exceptions.

Source: Interview with Mira on 2026-09-19.
