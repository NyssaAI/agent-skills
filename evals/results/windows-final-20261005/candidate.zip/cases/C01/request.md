# C01: Classification and ownership

For this task, today's date is 2026-09-29. All identities and records are synthetic. Treat workspace/ as this task's root. There is no external evidence or version history unless this request explicitly supplies it. Do not invent missing facts.

Start with the frozen para-vault skill in ../../plugin/skills/ (resolve from the candidate root if necessary) and load applicable references.

Give filing decisions only; do not change the workspace.
For each item, put a category in response.decisions using Projects, Areas, Resources, Archives, or unresolved.
guide: an interview guide maintained by the recruiting function and reused by three hiring projects.
candidate: a candidate evaluation used only for the active designer hiring project.
reference: a coffee brewing article retained for personal learning, with no operational responsibility.
closed: the complete records of an abandoned app launch with no active owner.
unknown: an unexplained capture whose purpose and usefulness are unknown.
override: a note I explicitly want kept in Resources even though it discusses an active project.
Explain your decisions briefly in your summary.

Complete authorized changes inside workspace/. If a decision needs unavailable user input, complete independent work and record the question rather than waiting. Write your final response to response.json alongside this request, using this shape:

```json
{
  "case_id": "Cxx",
  "status": "completed | needs-input | review-only",
  "summary": "What you actually did or found, with relevant paths and uncertainty.",
  "questions": [],
  "limitations": [],
  "decisions": {}
}
```
