---
type: note
created: 2026-08-01
status: draft
canonical: true
---

Canonical designation: 2026-09-20T12:00:00Z.
Expense limit: 150.
