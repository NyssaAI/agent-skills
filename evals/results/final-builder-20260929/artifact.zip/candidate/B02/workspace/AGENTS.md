# Existing project instructions

Keep user notes private.

Keep disposable task output under .temp/. Preserve existing notes.
