# Writing voice

## Scope
This project; sparse evidence from two AUTHOR lines in samples/mine.txt. Limited to explicit preferences; no established voice match is claimed.

## Explicit preferences
- Use contractions.
- Use no exclamation marks.
- Use plain words.

## Evidence and confidence
Direct user request, 2026-09-29. Preferences are approved; broader habits are not inferred.
