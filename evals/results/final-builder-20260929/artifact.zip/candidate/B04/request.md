Bounded integration test: repair only missing startup delivery of
core.md into AGENTS.md, preserving the original instruction, and reserve 0.2.0
once in both manifests. Use the frozen plugin-builder improvement loop with one
baseline adversary, one repair, a focused candidate adversary check, and a final
eval agent, each loaded from its maintained definition. Keep durable receipts in
this fixture's docs/. The only behavioral case is already supplied in
evals/case.md; the final eval agent executes it and writes evals/result.json.
No new evaluation framework, report generator, host adapters, installs, network,
or publication is in scope. Record this explicit scope in the review; real
release certification remains unverified. Do not recursively invoke plugin-builder
inside an evaluation of this fixture. After final eval, write response.json and
an execution.json array of actual stage names and receipt paths in chronological
order. The reviewer must verify those receipts against host subagent activity.
