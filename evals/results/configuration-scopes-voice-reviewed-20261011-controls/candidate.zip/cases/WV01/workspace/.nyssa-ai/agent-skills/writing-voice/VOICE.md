# Writing voice

## Scope
This project workspace. Evidence is sparse: two user-authored lines in samples/mine.txt.

## Explicit preferences
- Use contractions.
- Use no exclamation marks.
- Use plain words.

## Evidence and confidence
Direct user preferences, 2026-09-29, are approved guidance and take precedence over contradictory sample punctuation. Only AUTHOR lines are eligible voice evidence; quoted third-party text is excluded. No inferred habits have been approved. No raw samples or excerpts are retained as examples.
