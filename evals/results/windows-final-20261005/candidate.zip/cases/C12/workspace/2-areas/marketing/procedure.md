---
type: note
created: 2026-09-20
document-maturity: draft
---

# Procedure

Unrelated marketing policy.
