---
type: note
created: 2026-09-29
document-maturity: draft
---

# Mobile accessibility

Customer Rowan needs keyboard navigation on mobile.
