from pathlib import Path
import json
w=Path(__file__).resolve().parents[1]
core=(w/'skills/sample-notes/core.md').read_bytes()
p=w/'AGENTS.md'
data=p.read_bytes()
if core not in data:
    p.write_bytes(data+core)
for rel in ('plugin.json','.claude-plugin/plugin.json'):
    p=w/rel
    obj=json.loads(p.read_text(encoding='utf-8'))
    obj['version']='0.2.0'
    p.write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8')
