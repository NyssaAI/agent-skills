# SC03: User write without vault

For this task, today's date is 2026-09-29. All identities and records are synthetic. Treat workspace/ as this task's root. There is no external evidence or version history unless this request explicitly supplies it. Do not invent missing facts.

Start with the frozen maintain-writing-voice skill in ../../plugin/skills/ (resolve from the candidate root if necessary) and load applicable references.

Verified synthetic home is home. No project or vault exists. Save this explicit voice preference for all projects: prefer direct requests. This isolated non-Git home has no synchronization or packaging and I accept private local Markdown storage. Create only the user bundle and report its scope/path; no project log is required.

Complete authorized changes inside workspace/. If a decision needs unavailable user input, complete independent work and record the question rather than waiting. Write your final response to response.json alongside this request, using this shape:

```json
{
  "case_id": "Cxx",
  "status": "completed | needs-input | review-only",
  "summary": "What you actually did or found, with relevant paths and uncertainty.",
  "questions": [],
  "limitations": [],
  "decisions": {}
}
```
