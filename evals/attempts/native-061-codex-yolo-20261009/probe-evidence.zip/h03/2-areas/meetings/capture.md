---
type: note
created: 2026-10-08
document-maturity: raw
---
# Meeting practice
Keep an agenda and record decisions. This supports the ongoing meetings responsibility.

## Lifecycle history

2026-10-09: Archived and reactivated into the meetings Area at the user's request.
- archived: 2026-10-09
- archived-from: 2-areas/meetings/capture.md
- archive-reason: User-requested lifecycle exercise
- Former archive location: 4-archives/capture.md
