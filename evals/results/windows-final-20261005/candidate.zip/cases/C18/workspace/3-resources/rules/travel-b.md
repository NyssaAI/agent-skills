---
type: note
created: 2026-09-20
document-maturity: established
canonical: true
---

Travel limit: 200.
