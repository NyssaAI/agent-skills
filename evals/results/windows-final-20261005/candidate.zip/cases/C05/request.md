# C05: User layout and source destination override

For this task, today's date is 2026-09-29. All identities and records are synthetic. Treat workspace/ as this task's root. There is no external evidence or version history unless this request explicitly supplies it. Do not invent missing facts.

Start with the frozen para-vault skill in ../../plugin/skills/ (resolve from the candidate root if necessary) and load applicable references.

This vault uses Capture, Work, Operations, Library, and History.
Capture/Originals preserves processed captures. Do not introduce numbered PARA folders or an email Area.
File Capture/approval.eml unchanged into Work/launch/evidence/approval.eml, the source-record destination I selected.
Update Work/launch/launch-index.md. Keep this native email format.

Complete authorized changes inside workspace/. If a decision needs unavailable user input, complete independent work and record the question rather than waiting. Write your final response to response.json alongside this request, using this shape:

```json
{
  "case_id": "Cxx",
  "status": "completed | needs-input | review-only",
  "summary": "What you actually did or found, with relevant paths and uncertainty.",
  "questions": [],
  "limitations": [],
  "decisions": {}
}
```
