---
type: note
created: 2026-09-28
document-maturity: established
canonical: true
---

Canonical designation: 2026-09-01T12:00:00Z.
Expense limit: 100.
