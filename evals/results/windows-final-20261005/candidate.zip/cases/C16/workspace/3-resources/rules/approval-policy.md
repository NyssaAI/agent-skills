---
type: note
created: 2026-09-20
document-maturity: established
canonical: true
tags: [policy]
---

# Approval policy

Two reviewers must approve every release.
Canonical designation: 2026-09-01T12:00:00Z.
