---
type: note
created: 2026-09-20
status: established
canonical: true
---

Canonical designation: 2026-09-28T12:00:00Z.
Expense limit: 900.
