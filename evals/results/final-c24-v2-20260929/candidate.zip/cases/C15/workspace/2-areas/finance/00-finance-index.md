---
type: moc
created: 2026-09-20
status: draft
---

# Finance

Active record: [Record](record.txt); [archive and reactivation history](record-txt-archive-metadata.md).
