---
type: moc
created: 2026-09-20
document-maturity: draft
---

# Finance

[Project-owned procedure](../../1-projects/2026.09.10-site-launch/discovery/procedure.md#evidence)
