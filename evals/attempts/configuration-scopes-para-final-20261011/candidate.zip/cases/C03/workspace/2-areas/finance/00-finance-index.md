---
type: moc
created: 2026-09-20
document-maturity: draft
---

# Finance

Procedures.

[Escalation procedure](escalation-procedure.md) ? vendor exceptions; audit A-17.
