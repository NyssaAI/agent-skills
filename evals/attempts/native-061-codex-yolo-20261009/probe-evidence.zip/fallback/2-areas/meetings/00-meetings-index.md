---
type: moc
created: 2026-10-08
document-maturity: reviewed
---
# Meetings
Meeting notes and invitations.

- [[2-areas/meetings/meeting-notes-2|Meeting notes (draft)]] — Agenda and decisions to be completed.
