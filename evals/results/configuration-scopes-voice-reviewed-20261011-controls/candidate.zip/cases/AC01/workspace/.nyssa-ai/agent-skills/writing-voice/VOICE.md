# Writing voice

## Scope
Project workspace only. Isolated, non-Git, unshared local storage accepted by the user.

## Explicit preferences
- Use direct requests.

## Evidence and confidence
Direct user instruction, 2026-09-29. Only this preference is established; no samples or broader voice evidence were supplied.
