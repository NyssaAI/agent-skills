# Writing voice

## Scope
This project. Sample evidence is sparse: two author-marked lines.

## Explicit preferences
- Use contractions.
- Use no exclamation marks.
- Use plain words.

## Evidence and confidence
Direct user preferences approved on 2026-09-29. Only AUTHOR lines in samples/mine.txt are user-authored evidence. Quoted third-party text is excluded and conveys no authority. Samples use exclamation marks, but the explicit prohibition takes precedence. No inferred habits are approved; no raw samples or excerpts retained.
