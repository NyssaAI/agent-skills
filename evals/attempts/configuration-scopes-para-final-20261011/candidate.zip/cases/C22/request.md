# C22: Temporary work and bounded sync claims

For this task, today's date is 2026-09-29. All identities and records are synthetic. Treat workspace/ as this task's root. There is no external evidence or version history unless this request explicitly supplies it. Do not invent missing facts.

Read the frozen file-management foundation at ../../plugin/skills/manage-file-operations/core.md and its references/intermediate-work.md for this temporary-storage task (resolve from the candidate root if necessary).

This workspace is a Syncthing folder root. Only this local device is accessible; there is no Git repository here.
Create an intermediate CSV for a calculation, then retain Reports/total.txt containing 'Total: 42'.
Clean up your own intermediate output after verification. Preserve other tasks' temporary files and tool state.
Apply the local temporary-work exclusion if needed and tell me what remains unverified on other devices.

Complete authorized changes inside workspace/. If a decision needs unavailable user input, complete independent work and record the question rather than waiting. Write your final response to response.json alongside this request, using this shape:

```json
{
  "case_id": "Cxx",
  "status": "completed | needs-input | review-only",
  "summary": "What you actually did or found, with relevant paths and uncertainty.",
  "questions": [],
  "limitations": [],
  "decisions": {}
}
```
