---
type: note
created: 2026-09-20
document-maturity: draft
---

# Procedure

## Evidence

Source token MOVE-12. [Receipt](receipt.txt)
