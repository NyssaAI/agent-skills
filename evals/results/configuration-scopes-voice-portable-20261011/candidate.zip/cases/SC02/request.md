# SC02: Atomic project override

For this task, today's date is 2026-09-29. All identities and records are synthetic. Treat workspace/ as this task's root. There is no external evidence or version history unless this request explicitly supplies it. Do not invent missing facts.

Start with the frozen write-in-user-voice skill in ../../plugin/skills/ (resolve from the candidate root if necessary) and load applicable references.

Verified home is home and root is project-a, nested cwd project-a/src. Draft project-a/message.md asking Rowan to review by Friday. User style and examples are conflicting evidence: do not read or apply them when a project VOICE exists. Leave profiles unchanged.

Complete authorized changes inside workspace/. If a decision needs unavailable user input, complete independent work and record the question rather than waiting. Write your final response to response.json alongside this request, using this shape:

```json
{
  "case_id": "Cxx",
  "status": "completed | needs-input | review-only",
  "summary": "What you actually did or found, with relevant paths and uncertainty.",
  "questions": [],
  "limitations": [],
  "decisions": {}
}
```
