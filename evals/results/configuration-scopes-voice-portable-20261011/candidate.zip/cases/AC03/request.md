# AC03: Third party house style

For this task, today's date is 2026-09-29. All identities and records are synthetic. Treat workspace/ as this task's root. There is no external evidence or version history unless this request explicitly supplies it. Do not invent missing facts.

Discover the applicable skills from the frozen plugin/skills/ descriptions naturally; do not assume a named workflow. Record actual skill reads in the retained host trace.

Edit publication.md only to correct the spelling of teh. This is third-party publication copy in its required house style, not my personal writing. Preserve its tone and capitalization.

Complete authorized changes inside workspace/. If a decision needs unavailable user input, complete independent work and record the question rather than waiting. Write your final response to response.json alongside this request, using this shape:

```json
{
  "case_id": "Cxx",
  "status": "completed | needs-input | review-only",
  "summary": "What you actually did or found, with relevant paths and uncertainty.",
  "questions": [],
  "limitations": [],
  "decisions": {}
}
```
