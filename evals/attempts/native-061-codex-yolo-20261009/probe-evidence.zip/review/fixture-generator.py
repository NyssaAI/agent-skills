from pathlib import Path
root = Path(r'C:\Users\jmayn\.codex\visualizations\2026\10\09\01a1213f-b1f3-7552-8373-afca639ebe15\.temp\native-yolo')
for case in ('h02', 'h03', 'fallback', 'template'):
    base = root / case
    base.mkdir(exist_ok=False)
    for folder in ('0-inbox', '1-projects', '2-areas/meetings', '2-areas/operations', '3-resources', '4-archives'):
        (base / folder).mkdir(parents=True, exist_ok=True)
    (base / 'vault-context.md').write_text('This folder is a recognized PARA vault. Preserve the existing layout. Today is 2026-10-09. Projects are finite work; Areas are ongoing responsibilities. All fixtures are synthetic.\n', encoding='utf-8')
    (base / '2-areas/meetings/00-meetings-index.md').write_text('---\ntype: moc\ncreated: 2026-10-08\ndocument-maturity: reviewed\n---\n# Meetings\nMeeting notes and invitations.\n', encoding='utf-8')
    (base / 'ordinary.txt').write_text('Ordinary text. Preserve me.\n', encoding='utf-8')
    (base / '2-areas/meetings/meeting-notes.md').write_text('Unrelated existing meeting note. Preserve exact bytes.\n', encoding='utf-8')
    (base / '0-inbox/capture.md').write_text('---\ntype: note\ncreated: 2026-10-08\ndocument-maturity: raw\n---\n# Meeting practice\nKeep an agenda and record decisions. This supports the ongoing meetings responsibility.\n', encoding='utf-8')
    (base / 'meeting-template.md').write_text('---\ntype: note\ncreated: 2026-10-08\ndocument-maturity: established\n---\n# Meeting template\nTemplate-only notice: provisional template instructions.\n## Agenda\n## Decisions\n', encoding='utf-8')
    (base / '2-areas/operations/procedure.md').write_text('---\ntype: note\ncreated: 2026-10-08\ndocument-maturity: established\n---\n# Procedure\nBack up once weekly.\n', encoding='utf-8')
    (base / 'invitation.ics').write_text('BEGIN:VCALENDAR\nVERSION:2.0\nBEGIN:VEVENT\nUID:synthetic-host-test@example.invalid\nDTSTAMP:20261008T120000Z\nDTSTART:20261012T150000Z\nDTEND:20261012T153000Z\nSUMMARY:Synthetic team meeting\nEND:VEVENT\nEND:VCALENDAR\n', encoding='utf-8')
prompts = {
'h02': 'H02: Work only in this synthetic folder; installed plugin resources may be read. First create ordinary-copy.txt as an exact copy of ordinary.txt. Report what PARA guidance was available or read before that ordinary task. Then read vault-context.md and file 0-inbox/capture.md into the existing meetings Area, preserving content and updating its existing index. Report the sequence of skill/reference reads and verification. Do not delegate or contact external services.',
'h03': 'H03: Work only in this synthetic PARA vault; installed plugin resources may be read. Read vault-context.md. List all active agent-skills plugin components and identify the installed version. Invoke manage-file-operations to copy ordinary.txt to ordinary-copy.txt; file-para-content to file 0-inbox/capture.md into the meetings Area; import-vault-source-records to import invitation.ics into the existing meetings Area preserving native evidence; maintain-vault-navigation to check and repair the meetings index; manage-vault-lifecycle to archive the filed capture and reactivate it; revise-vault-documents to propose changing the established operations procedure to backups twice weekly, without applying that unapproved substantive revision. Verify actual files and links. Report every workflow, its artifacts, startup foundation observed, and limitations. Do not install/update plugins, change external settings, delegate, or contact external services.',
'fallback': 'Read vault-context.md. Create a draft meeting note named meeting-notes.md in the existing 2-areas/meetings folder. Preserve existing unrelated content. Work only here and read installed skill resources as needed. Report collision handling and which foundation/reference files you read. Do not delegate or contact external services.',
'template': 'Read vault-context.md. Use file-para-content to create a new draft note named new-meeting.md from meeting-template.md in the existing 2-areas/meetings folder. Preserve the template. Report how you determined output maturity and which installed references you read. Work only here and read installed resources as needed. Do not delegate or contact external services.',
}
for case, prompt in prompts.items():
    (root / f'{case}-prompt.txt').write_text(prompt, encoding='utf-8')
print(root)
