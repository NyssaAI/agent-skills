---
type: note
created: 2026-10-09
document-maturity: draft
---
# New meeting

## Agenda

## Decisions
