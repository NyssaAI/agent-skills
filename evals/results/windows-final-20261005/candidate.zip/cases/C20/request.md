# C20: Finish interrupted move without recreating source

For this task, today's date is 2026-09-29. All identities and records are synthetic. Treat workspace/ as this task's root. There is no external evidence or version history unless this request explicitly supplies it. Do not invent missing facts.

Start with the frozen file-management skill in ../../plugin/skills/ (resolve from the candidate root if necessary) and load applicable references.

A move from Incoming/report.txt to Records/report.txt completed its file transfer but stopped before link repair.
Finish this move. Records/report.txt is the verified destination, with Source-ID retry-20. The source is already gone.
Keep unrelated file references unchanged and do not create another retained copy.

Complete authorized changes inside workspace/. If a decision needs unavailable user input, complete independent work and record the question rather than waiting. Write your final response to response.json alongside this request, using this shape:

```json
{
  "case_id": "Cxx",
  "status": "completed | needs-input | review-only",
  "summary": "What you actually did or found, with relevant paths and uncertainty.",
  "questions": [],
  "limitations": [],
  "decisions": {}
}
```
