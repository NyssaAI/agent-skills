---
type: moc
created: 2026-09-20
status: draft
---

# Calendar

Meetings.

- [Planning recurring series](we-2026.09.27/2026.09.21-planning-series.ics) � weekly series starting September 21 UTC.
- [Planning September 28 occurrence rescheduled](we-2026.10.04/2026.09.29-planning-exception.ics) � separate exception starting September 29 UTC.

