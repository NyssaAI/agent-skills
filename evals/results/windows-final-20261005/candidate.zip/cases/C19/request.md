# C19: Distinct collision and duplicate retry

For this task, today's date is 2026-09-29. All identities and records are synthetic. Treat workspace/ as this task's root. There is no external evidence or version history unless this request explicitly supplies it. Do not invent missing facts.

Start with the frozen file-management skill in ../../plugin/skills/ (resolve from the candidate root if necessary) and load applicable references.

Move Incoming/report.txt into Records. Records/report.txt belongs to a different record and must remain.
Incoming/repeat.txt is another delivery of the exact same source record already at Records/report-2.txt.
Reuse the identical retained record rather than creating another copy for that delivery.
Update the existing Records/index.md with useful links. Source identifiers are embedded in the payloads.

Complete authorized changes inside workspace/. If a decision needs unavailable user input, complete independent work and record the question rather than waiting. Write your final response to response.json alongside this request, using this shape:

```json
{
  "case_id": "Cxx",
  "status": "completed | needs-input | review-only",
  "summary": "What you actually did or found, with relevant paths and uncertainty.",
  "questions": [],
  "limitations": [],
  "decisions": {}
}
```
