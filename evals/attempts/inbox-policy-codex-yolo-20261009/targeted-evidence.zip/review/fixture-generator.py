import hashlib
import json
import shutil
import sys
from pathlib import Path

repo = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(repo/'evals'))
from cases import build_cases
root = Path(r'C:\Users\jmayn\.codex\visualizations\2026\10\09\01a1213f-b1f3-7552-8373-afca639ebe15\.temp\inbox-policy-probe')
root.mkdir(exist_ok=False)
shutil.copytree(repo/'skills', root/'skills')
packet = ['Execute these synthetic user requests in their separate workspace folders. Use ONLY the frozen skills under this packet directory for skill instructions; ignore older installed versions for these tasks. Today is 2026-09-29. All case workspaces are recognized PARA vaults. Read the frozen entrypoint for each case and relevant references. Write only the case workspaces and a response.md in each case folder. Do not read eval/scoring materials or files outside this directory except normal host tools. Do not delegate, fetch sources, contact external services, install plugins, or alter frozen skills. Report actual changes, source provenance, retained history, and limitations for each task.']
for case in build_cases():
    if case['id'] not in ('C03','C07','C23'):
        continue
    workspace = root/case['id']/'workspace'
    workspace.mkdir(parents=True)
    for directory in case['directories']:
        (workspace/directory).mkdir(parents=True, exist_ok=True)
    for relative, content in case['files'].items():
        path = workspace/relative
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(content,encoding='utf-8',newline='\n')
    packet.append(f"Case {case['id']}: Working root {workspace.as_posix()}. Read skills/{case['entry_skill']}/SKILL.md.\n{case['prompt']}")
for case in ('duplicate-inbox-capture','accessible-source-link-only'):
    source = repo/'evals/tessl/source-record-boundaries'/case
    shutil.copytree(source/'fixture/workspace', root/case/'workspace')
    prompt=(source/'task.md').read_text(encoding='utf-8')
    packet.append(f"Case {case}: Working root {(root/case/'workspace').as_posix()}. Read skills/import-vault-source-records/SKILL.md.\n{prompt}")
(root/'PACKET.md').write_text('\n\n'.join(packet),encoding='utf-8')
inventory={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file()}
(repo/'.temp/inbox-policy-before.json').write_text(json.dumps(inventory,indent=2),encoding='utf-8')
print(root)
