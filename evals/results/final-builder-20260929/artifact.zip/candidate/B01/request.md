Review only: inspect this sample plugin and its supplied host inventory.
Write response.json with a findings list and a next_action string. Each finding
must identify the file and an observable acceptance check. Do not modify the
workspace, run a full review cycle, or contact/install a host. Use the inventory
as the fixture's facts; distinguish missing implementation from external blockers.
Scope this case to finding detection and choosing a runnable development probe.
