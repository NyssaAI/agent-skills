---
type: note
created: 2026-09-29
document-maturity: draft
canonical: false
tags: [policy]
---

# Proposed approval-policy revision

Pending approval. Accepted original: [[3-resources/rules/approval-policy|Approval policy]].

## Proposed text

One reviewer must approve every release.

## Rationale and risk

Replacing two required reviewers with one removes the second approval dependency and may reduce review waiting time. No measured time saving is available in this fixture. It also removes a second independent check, increasing the chance that an error or overlooked concern reaches release and concentrating judgment in one reviewer. The accepted two-reviewer rule continues to govern until this specific revision is approved.
