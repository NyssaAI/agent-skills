Rowan, can you review this by Friday?
