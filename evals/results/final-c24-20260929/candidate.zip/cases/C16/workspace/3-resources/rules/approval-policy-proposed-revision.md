---
type: note
created: 2026-09-29
status: draft
canonical: false
tags: [policy]
---

# Proposed approval policy revision

Proposal for [[approval-policy]]: replace the two-reviewer requirement with: One reviewer must approve every release.

This could reduce review time by waiting for only one reviewer. It also removes an independent check, increasing the chance that a release error or missed issue passes approval. This proposal is pending approval; the accepted two-reviewer policy remains in force.
