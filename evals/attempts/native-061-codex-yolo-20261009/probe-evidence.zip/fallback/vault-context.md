This folder is a recognized PARA vault. Preserve the existing layout. Today is 2026-10-09. Projects are finite work; Areas are ongoing responsibilities. All fixtures are synthetic.
