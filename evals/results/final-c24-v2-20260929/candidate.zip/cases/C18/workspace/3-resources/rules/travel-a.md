---
type: note
created: 2026-09-20
status: established
canonical: true
---

Travel limit: 100.
