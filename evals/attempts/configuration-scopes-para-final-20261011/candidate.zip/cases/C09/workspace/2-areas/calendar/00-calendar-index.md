---
type: moc
created: 2026-09-20
document-maturity: draft
---

# Calendar

Current: [Planning](we-2026.10.11/2026.10.05-planning.ics)

Historical snapshot: [Previous planning](we-2026.10.04/2026.09.30-planning.ics). Equal sequence 4; newer DTSTAMP 2026-09-26 governs supplied local evidence. Live state not checked.
