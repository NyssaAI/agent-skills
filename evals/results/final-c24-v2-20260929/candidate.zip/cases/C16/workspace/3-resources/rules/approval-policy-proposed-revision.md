---
type: note
created: 2026-09-29
status: draft
canonical: false
tags: [policy]
---

# Proposed approval policy revision

Accepted policy: [[approval-policy]].

Proposed wording: One reviewer must approve every release.

This would reduce the time spent waiting for a second review, but removes an independent check and increases the risk that a release error is missed. The accepted policy remains in force pending approval.
