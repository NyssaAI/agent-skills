---
type: moc
created: 2026-09-20
document-maturity: draft
---

# Finance

Active: [[1-projects/2026.08.01-launch/2026.08.01-launch-index|Launch]]
