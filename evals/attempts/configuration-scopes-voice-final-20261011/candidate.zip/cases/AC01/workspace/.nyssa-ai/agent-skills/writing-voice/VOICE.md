# Writing voice

## Scope
This project. Only the explicit preference below is established.

## Explicit preferences
- Use direct requests.

## Evidence and confidence
Direct user instruction, 2026-09-29; approved preference. No broader voice characteristics inferred.
