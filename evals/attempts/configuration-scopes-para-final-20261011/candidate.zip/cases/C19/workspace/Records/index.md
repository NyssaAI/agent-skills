# Records

[Original](report.txt)
[Retained](report-2.txt)

[New distinct report](report-3.txt) ? Source-ID new-19. The duplicate delivery of Source-ID existing-19 reuses [Retained](report-2.txt).
