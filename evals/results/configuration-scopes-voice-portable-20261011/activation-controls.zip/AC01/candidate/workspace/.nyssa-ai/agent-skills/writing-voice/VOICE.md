﻿# Project writing voice

## Scope
Applies to writing for this project, rooted at workspace/. This profile records one explicit preference; no writing samples or broader voice patterns have been assessed. Current task instructions and required destination standards take precedence.

## Explicit preferences
- Use direct requests.

## Evidence and confidence
- Source: the direct user request in request.md to save this preference for this project.
- Confidence: high for the explicitly stated preference. No additional voice characteristics are inferred.
