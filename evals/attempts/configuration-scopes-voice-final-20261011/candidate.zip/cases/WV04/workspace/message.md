Rowan, please review the pilot draft by Friday. The pilot has 12 participants, and launch timing is still uncertain.
