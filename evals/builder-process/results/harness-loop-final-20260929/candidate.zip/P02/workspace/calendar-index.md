Current: [Planning](current.ics)
Historical: [Planning](old.ics) � older invitation.
