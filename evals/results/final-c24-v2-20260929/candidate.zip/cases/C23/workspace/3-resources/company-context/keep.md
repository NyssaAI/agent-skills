---
type: note
created: 2026-09-20
status: established
---

# Accepted context

Retain this evidence.
