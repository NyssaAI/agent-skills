---
type: moc
created: 2026-09-20
document-maturity: draft
---

# Calendar

Current: [Planning](we-2026.10.11/2026.10.05-planning.ics)

Historical: [Previous planning date](we-2026.10.04/2026.09.30-planning.ics) — same sequence 4, older DTSTAMP 20260925T120000Z. Current update has DTSTAMP 20260926T120000Z.
