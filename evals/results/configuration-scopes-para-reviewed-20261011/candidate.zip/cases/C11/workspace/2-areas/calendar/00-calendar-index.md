---
type: moc
created: 2026-09-20
document-maturity: draft
---

# Calendar

Meetings.

- [Planning series snapshot](we-2026.09.27/2026.09.21-series.ics) ? UID weekly-11@example.test; DTSTART September 21 UTC, weekly count 4.
- [Planning occurrence exception snapshot](we-2026.10.04/2026.09.29-exception.ics) ? same UID, RECURRENCE-ID 20260928T150000Z; actual occurrence starts September 29 UTC. Distinct recurrence identity, not a replacement series.

Live calendar state was not checked.
