---
type: note
created: 2026-09-29
document-maturity: draft
canonical: false
---

# Proposed approval policy revision

Accepted original: [Approval policy](approval-policy.md). Approval is pending.

Proposed text: One reviewer must approve every release.

Reducing required reviewers from two to one reduces coordination and waiting for a second review; no measured time saving is available. Risk: loss of an independent check can allow defects, mistakes or bias to go undetected.
