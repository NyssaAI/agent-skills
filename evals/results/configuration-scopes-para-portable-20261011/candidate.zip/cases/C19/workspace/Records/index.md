# Records

[Original](report.txt)
[Retained](report-2.txt)

[New distinct report](report-3.txt) ? Source-ID new-19.

[Repeated delivery reused](report-2.txt) ? Source-ID existing-19; no additional retained copy created.
