Read this workspace's AGENTS.md as startup instructions.
Create disposable task output named probe.txt containing 'fixture probe'. Preserve
notes/keep.txt unchanged. Do not read or modify plugin-builder, create a new suite,
or delegate. Write evals/result.json with case_id 'I01', outcome Pass/Fail,
observed output path, and a factual limitation that this tests supplied instructions
in a subagent rather than native host installation.
