---
type: note
created: 2026-09-29
document-maturity: draft
canonical: false
---

# Mobile accessibility

Customer Rowan needs keyboard navigation on mobile. This request belongs to site-launch discovery.
