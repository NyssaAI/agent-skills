# WV05: Nested root and separate-project isolation

For this task, today's date is 2026-09-29. All identities and records are synthetic. Treat workspace/ as this task's root. There is no external evidence or version history unless this request explicitly supplies it. Do not invent missing facts.

Start with the frozen write-in-user-voice skill in ../../plugin/skills/ (resolve from the candidate root if necessary) and load applicable references.

Two separate established non-Git project roots live here: project-a and project-b.
The active project is project-a; your nested working directory is project-a/src/nested, which is not a new project root.
Draft as me from project-a's profile: ask Rowan to review the draft by Friday. Save project-a/message.md.
Do not use project-b's profile, create a nested profile, or update either project's configuration.

Complete authorized changes inside workspace/. If a decision needs unavailable user input, complete independent work and record the question rather than waiting. Write your final response to response.json alongside this request, using this shape:

```json
{
  "case_id": "Cxx",
  "status": "completed | needs-input | review-only",
  "summary": "What you actually did or found, with relevant paths and uncertainty.",
  "questions": [],
  "limitations": [],
  "decisions": {}
}
```
