---
type: moc
created: 2026-09-20
document-maturity: draft
---

# Finance

Active record: [Record](record.txt) ? [Lifecycle history](record-txt-archive-metadata.md)
