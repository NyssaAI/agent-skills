---
type: moc
created: 2026-09-20
status: draft
---

# Finance

Procedures.

- [[escalation-procedure]] � vendor-exception escalation procedure (audit A-17).

