# Records

[Original](report.txt)
[Retained](report-2.txt)

[New distinct report](report-3.txt) — Source-ID new-19.

The retained report-2.txt already holds Source-ID existing-19; its identical repeat delivery reuses that record.
