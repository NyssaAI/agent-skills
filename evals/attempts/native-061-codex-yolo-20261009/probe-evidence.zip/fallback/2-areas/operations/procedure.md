---
type: note
created: 2026-10-08
document-maturity: established
---
# Procedure
Back up once weekly.
