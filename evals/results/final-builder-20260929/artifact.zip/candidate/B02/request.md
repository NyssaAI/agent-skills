Implement only this accepted repair: AGENTS.md does not contain the
canonical core.md rules. Add their exact body once while preserving the existing
instruction. This fixture's previous released version is 0.1.0: reserve 0.2.0 in
plugin.json and .claude-plugin/plugin.json. Check the fix and repeat the setup
operation to establish idempotence; do not bump again for the same candidate.
Write response.json. No additional hosts, eval framework, or subagents are needed
for this deliberately scoped component test.
