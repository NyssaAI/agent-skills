---
type: moc
created: 2026-09-20
status: draft
---

# Finance

[Project procedure](../../1-projects/2026.09.10-site-launch/discovery/procedure.md#evidence) ? now owned by site launch.
