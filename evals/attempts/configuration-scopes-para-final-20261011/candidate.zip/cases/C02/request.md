# C02: Create a project without inventing a deadline

For this task, today's date is 2026-09-29. All identities and records are synthetic. Treat workspace/ as this task's root. There is no external evidence or version history unless this request explicitly supplies it. Do not invent missing facts.

Start with the frozen file-para-content skill in ../../plugin/skills/ (resolve from the candidate root if necessary) and load applicable references.

Create a new payroll-migration project today.
Its goal is to migrate payroll processing to the new provider. Finance owns the ongoing responsibility.
We have not agreed a deadline. Create the project index and connect it to finance navigation.

Complete authorized changes inside workspace/. If a decision needs unavailable user input, complete independent work and record the question rather than waiting. Write your final response to response.json alongside this request, using this shape:

```json
{
  "case_id": "Cxx",
  "status": "completed | needs-input | review-only",
  "summary": "What you actually did or found, with relevant paths and uncertainty.",
  "questions": [],
  "limitations": [],
  "decisions": {}
}
```
