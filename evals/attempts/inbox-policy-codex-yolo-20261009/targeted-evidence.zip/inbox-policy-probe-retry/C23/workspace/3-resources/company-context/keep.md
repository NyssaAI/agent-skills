---
type: note
created: 2026-09-20
document-maturity: established
---

# Accepted context

Retain this evidence.
