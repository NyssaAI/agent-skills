# C12: Move with inbound links and attachment

For this task, today's date is 2026-09-29. All identities and records are synthetic. Treat workspace/ as this task's root. There is no external evidence or version history unless this request explicitly supplies it. Do not invent missing facts.

Start with the frozen para-vault skill in ../../plugin/skills/ (resolve from the candidate root if necessary) and load applicable references.

Move 2-areas/finance/procedure.md and its exclusively owned receipt.txt into 1-projects/2026.09.10-site-launch/discovery/.
The procedure now belongs to this project. Repair affected navigation and links. Preserve its created date and content.
The similarly named marketing procedure is unrelated.

Complete authorized changes inside workspace/. If a decision needs unavailable user input, complete independent work and record the question rather than waiting. Write your final response to response.json alongside this request, using this shape:

```json
{
  "case_id": "Cxx",
  "status": "completed | needs-input | review-only",
  "summary": "What you actually did or found, with relevant paths and uncertainty.",
  "questions": [],
  "limitations": [],
  "decisions": {}
}
```
