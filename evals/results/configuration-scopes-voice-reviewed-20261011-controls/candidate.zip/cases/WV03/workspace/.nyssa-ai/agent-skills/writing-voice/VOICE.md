# Synthetic voice profile

Approved preferences: plain words, contractions, no exclamation marks.
Email mode: greeting and a clear next step, short paragraphs.
Chat mode: one or two direct sentences; omit greetings.
Evidence: synthetic approved examples only; no claims about personal beliefs.

## Explicit preferences
- Prefer direct requests over rhetorical questions.
  Source: direct user authorization, 2026-09-29; stylistic correction in edits.md. The record count and delivery date corrections are factual, not voice guidance.
