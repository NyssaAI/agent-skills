---
type: moc
created: 2026-09-20
status: draft
---

# Finance

Active operational record: [Record](record.txt) ([archive history](record-txt-archive-metadata.md))
