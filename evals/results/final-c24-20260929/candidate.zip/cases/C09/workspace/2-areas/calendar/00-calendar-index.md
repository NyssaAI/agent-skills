---
type: moc
created: 2026-09-20
status: draft
---

# Calendar

Current: [Planning](we-2026.10.11/2026.10.05-planning.ics)

Historical: [Planning, prior September 30 start](we-2026.10.04/2026.09.30-planning.ics) — same sequence, older DTSTAMP.
