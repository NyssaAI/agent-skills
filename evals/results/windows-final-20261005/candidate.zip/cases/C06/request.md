# C06: Production dates and unknown dates

For this task, today's date is 2026-09-29. All identities and records are synthetic. Treat workspace/ as this task's root. There is no external evidence or version history unless this request explicitly supplies it. Do not invent missing facts.

Start with the frozen file-management skill in ../../plugin/skills/ (resolve from the candidate root if necessary) and load applicable references.

Use file-management to copy these native documents from Incoming into Records with descriptive names.
Rename report.txt using its publication date 2026-08-14 and the slug annual-report; its coverage is 2025.
Rename contract.txt using its signing date 2026-07-02 and the slug vendor-contract.
The original production date of undated-reference.txt is unknown; preserve its name.
Keep the Incoming originals. Today is the download date, not a new production date.

Complete authorized changes inside workspace/. If a decision needs unavailable user input, complete independent work and record the question rather than waiting. Write your final response to response.json alongside this request, using this shape:

```json
{
  "case_id": "Cxx",
  "status": "completed | needs-input | review-only",
  "summary": "What you actually did or found, with relevant paths and uncertainty.",
  "questions": [],
  "limitations": [],
  "decisions": {}
}
```
