Rowan, the pilot has 12 participants. The draft's due October 14, and launch timing is still uncertain. Please review by Friday.
