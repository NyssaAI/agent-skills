---
type: moc
created: 2026-10-08
document-maturity: reviewed
---
# Meetings
Meeting notes and invitations.

- [[2-areas/meetings/capture|Meeting practice]] — Keep an agenda and record decisions for the ongoing meetings responsibility.
