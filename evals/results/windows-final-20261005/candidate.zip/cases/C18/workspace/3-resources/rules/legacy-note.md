---
type: note
created: 2026-09-20
status: reviewed
---

Accepted legacy note.
