# C07: Email timezone boundary

For this task, today's date is 2026-09-29. All identities and records are synthetic. Treat workspace/ as this task's root. There is no external evidence or version history unless this request explicitly supplies it. Do not invent missing facts.

Start with the frozen import-vault-source-records skill in ../../plugin/skills/ (resolve from the candidate root if necessary) and load applicable references.

File the incoming budget reply into the existing email Area using America/Chicago for filing.
Keep the budget-reply slug. The capture was authored today; preserve its source timestamps and review status.

Complete authorized changes inside workspace/. If a decision needs unavailable user input, complete independent work and record the question rather than waiting. Write your final response to response.json alongside this request, using this shape:

```json
{
  "case_id": "Cxx",
  "status": "completed | needs-input | review-only",
  "summary": "What you actually did or found, with relevant paths and uncertainty.",
  "questions": [],
  "limitations": [],
  "decisions": {}
}
```
