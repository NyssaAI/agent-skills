# Writing voice

## Scope
This project; only the explicit preference below is established.

## Explicit preferences
- Use direct requests.

## Evidence and confidence
Source: direct user request, 2026-09-29. Explicitly approved; no inferred habits or retained examples.
