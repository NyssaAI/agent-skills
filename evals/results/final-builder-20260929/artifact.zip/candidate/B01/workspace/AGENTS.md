# Existing project instructions

Keep user notes private.
