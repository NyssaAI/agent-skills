def accept(result):
    if result['outcome'] == 'Pass':
        return False
    return result['outcome'] == 'Fail'
