# C18: Canonical designation beats maturity and creation

For this task, today's date is 2026-09-29. All identities and records are synthetic. Treat workspace/ as this task's root. There is no external evidence or version history unless this request explicitly supplies it. Do not invent missing facts.

Start with the frozen para-vault skill in ../../plugin/skills/ (resolve from the candidate root if necessary) and load applicable references.

Answer only; do not modify documents.
Which rule governs expense reimbursement? Put its vault-relative file path in response.decisions.expenses.
Which travel rule governs? Put its path in response.decisions.travel, or 'unresolved' if you cannot decide.
Both pairs address exactly the same purpose within each pair. All available approval history is in the files.
Explain any missing information needed before applying a rule.

Complete authorized changes inside workspace/. If a decision needs unavailable user input, complete independent work and record the question rather than waiting. Write your final response to response.json alongside this request, using this shape:

```json
{
  "case_id": "Cxx",
  "status": "completed | needs-input | review-only",
  "summary": "What you actually did or found, with relevant paths and uncertainty.",
  "questions": [],
  "limitations": [],
  "decisions": {}
}
```
