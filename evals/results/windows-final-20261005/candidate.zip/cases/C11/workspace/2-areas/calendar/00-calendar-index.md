---
type: moc
created: 2026-09-20
document-maturity: draft
---

# Calendar

Meetings.

- [Weekly planning series](we-2026.09.27/2026.09.21-planning-series.ics) — native recurring series beginning September 21, sequence 1.
- [September 28 occurrence rescheduled to September 29](we-2026.10.04/2026.09.29-planning-exception.ics) — RECURRENCE-ID 20260928T150000Z, sequence 2; distinct occurrence identity under UID weekly-11@example.test.
