# Pilot update

Hi Rowan,

Please review the pilot draft by Friday. The pilot has 12 participants, and the draft is due October 14. Launch timing is uncertain.
