# WV06: User-selected sources and native records preserved

For this task, today's date is 2026-09-29. All identities and records are synthetic. Treat workspace/ as this task's root. There is no external evidence or version history unless this request explicitly supplies it. Do not invent missing facts.

Start with the frozen maintain-writing-voice skill in ../../plugin/skills/ (resolve from the candidate root if necessary) and load applicable references.

Inspect my existing profile at selected/my-voice.md as an authorized input and propose how to establish the project-local profile.
Do not apply a migration or persist changes yet. samples/native.eml is a source record with my authored line and a quoted third-party block; preserve its native bytes and do not rewrite the quoted text in my voice.
Explain which evidence you would use and which parts you would exclude. Do not move or delete my selected profile or native record.

Complete authorized changes inside workspace/. If a decision needs unavailable user input, complete independent work and record the question rather than waiting. Write your final response to response.json alongside this request, using this shape:

```json
{
  "case_id": "Cxx",
  "status": "completed | needs-input | review-only",
  "summary": "What you actually did or found, with relevant paths and uncertainty.",
  "questions": [],
  "limitations": [],
  "decisions": {}
}
```
