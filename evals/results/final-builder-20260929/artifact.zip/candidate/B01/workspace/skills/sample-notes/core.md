Keep disposable task output under .temp/. Preserve existing notes.
