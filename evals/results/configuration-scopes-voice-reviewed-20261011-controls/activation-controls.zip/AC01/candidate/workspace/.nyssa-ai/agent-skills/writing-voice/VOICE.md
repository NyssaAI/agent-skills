﻿# Project writing voice

## Scope
Applies to writing for this project. Current task instructions and required destination standards take precedence.

## Explicit preferences
- Use direct requests: state the requested action plainly.

## Evidence and confidence
Source: the user's explicit project preference, "use direct requests."
Confidence: high for this approved preference. No writing samples were supplied; no broader voice characteristics are inferred.
