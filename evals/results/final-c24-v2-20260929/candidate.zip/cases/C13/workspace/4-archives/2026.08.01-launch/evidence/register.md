---
type: note
created: 2026-09-20
status: draft
---

# Evidence

[Agreement](contracts/signed.txt)
