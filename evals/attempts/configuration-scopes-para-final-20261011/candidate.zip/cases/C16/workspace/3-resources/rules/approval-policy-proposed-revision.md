---
type: note
created: 2026-09-29
document-maturity: draft
canonical: false
---

# Proposed approval policy revision

Accepted original: [Approval policy](approval-policy.md). This proposal is pending approval.

Replace "Two reviewers must approve every release." with "One reviewer must approve every release."

A single reviewer may reduce coordination and waiting time by removing the need to secure a second approval. No measured time savings are supplied. The risk is reduced independent scrutiny: one reviewer may miss defects, errors, or conflicts that a second reviewer would catch.
