import hashlib
import json
import sys
from pathlib import Path

repo = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(repo/'evals'))
from cases import build_cases
from scoring import evaluate_check
root = Path(r'C:\Users\jmayn\.codex\visualizations\2026\10\09\01a1213f-b1f3-7552-8373-afca639ebe15\.temp\inbox-policy-probe')
retry = root.with_name('inbox-policy-probe-retry')
checks=[]
for case in build_cases():
    if case['id'] not in ('C03','C07','C23'):
        continue
    for assertion in case['checks']:
        case_root = retry if case['id'] == 'C23' else root
        passed,evidence = evaluate_check(assertion, case_root/case['id']/'workspace', case['files'], {})
        checks.append({'case':case['id'],'label':assertion['label'],'passed':passed,'evidence':evidence})
before=json.loads((repo/'.temp/inbox-policy-before.json').read_text(encoding='utf-8'))
for relative,expected in before.items():
    if relative == 'skills/file-para-content/SKILL.md':
        continue  # Retry preparation replaced this baseline; do not misattribute the policy clarification to the first candidate.
    if relative.startswith('skills/') or (relative.startswith('duplicate-inbox-capture/workspace/') and '0-inbox/' not in relative and relative.endswith('.ics')):
        checks.append({'case':'snapshot','label':relative,'passed':hashlib.sha256((root/relative).read_bytes()).hexdigest()==expected})
for relative,expected in before.items():
    if relative.startswith('skills/'):
        checks.append({'case':'retry-snapshot','label':relative,'passed':hashlib.sha256((retry/relative).read_bytes()).hexdigest()==expected})
b=root/'duplicate-inbox-capture/workspace'
checks.append({'case':'duplicate','label':'No new Inbox archive or pending duplicate','passed':not (b/'0-inbox/archive').exists() and not (b/'0-inbox/planning.ics').exists()})
b=root/'accessible-source-link-only/workspace'
files=[p for p in b.rglob('*') if p.is_file()]
index=b/'2-areas/email/00-email-index.md'
checks.append({'case':'link-only','label':'Source reference only','passed':files==[index] and 'https://mail.example.test/messages/budget-approval-29' in index.read_text(encoding='utf-8')})
result={'passed':all(c['passed'] for c in checks),'checks':checks,'scope':'Targeted native YOLO behavioral probe using frozen skill resources; C23 final filename check uses a separate fresh retry. Initial C23 trial added an unwanted date prefix; retained as failed trial. Not full host startup acceptance or a complete 24-case scored suite.'}
(repo/'.temp/inbox-policy-probe-checks.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'passed':result['passed'],'checks':len(checks),'failures':[c for c in checks if not c['passed']]},indent=2))
raise SystemExit(not result['passed'])
