Rowan, please review the draft by Friday.
