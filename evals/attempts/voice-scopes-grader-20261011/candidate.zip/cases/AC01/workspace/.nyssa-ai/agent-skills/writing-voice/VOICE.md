# Writing voice

## Scope
This project. Limited to explicit preferences; no established voice match is claimed.

## Explicit preferences
- Use direct requests.

## Evidence and confidence
Direct user request, 2026-09-29. Preferences are approved; broader habits are not inferred.
