---
type: moc
created: 2026-09-20
status: draft
---

# Finance

Procedures.

[Escalation procedure](escalation-procedure.md) ? vendor exceptions and audit A-17.
