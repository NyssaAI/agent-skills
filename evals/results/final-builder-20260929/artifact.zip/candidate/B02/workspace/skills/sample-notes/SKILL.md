---
name: sample-notes
description: Organize sample notes.
---

Read [core](core.md) before acting.
