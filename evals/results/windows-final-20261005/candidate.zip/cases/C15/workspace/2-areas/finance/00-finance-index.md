---
type: moc
created: 2026-09-20
document-maturity: draft
---

# Finance

Active record: [Record](record.txt) — [[2-areas/finance/record-txt-archive-metadata|Reactivation and archive history]].
