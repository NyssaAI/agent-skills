The pilot has 12 participants, the draft's due October 14, and launch timing is uncertain. Rowan, please review by Friday.
