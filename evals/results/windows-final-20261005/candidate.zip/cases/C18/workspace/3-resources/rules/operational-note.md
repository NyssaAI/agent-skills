---
type: note
created: 2026-09-20
status: completed
---

Only work state is known.
