---
type: moc
created: 2026-09-20
document-maturity: draft
---

# Calendar

Meetings.

[series.ics](we-2026.09.27/2026.09.21-planning-series.ics) ? supplied native snapshot; series UID weekly-11@example.test.

[exception.ics](we-2026.10.04/2026.09.29-planning-exception.ics) ? supplied native snapshot; RECURRENCE-ID 20260928T150000Z rescheduled to September 29.
