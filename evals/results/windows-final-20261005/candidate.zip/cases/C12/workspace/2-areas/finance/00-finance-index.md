---
type: moc
created: 2026-09-20
document-maturity: draft
---

# Finance

Project-owned: [Procedure](../../1-projects/2026.09.10-site-launch/discovery/procedure.md#evidence) — now maintained by site-launch discovery.
