---
type: note
created: 2026-09-20
document-maturity: raw
---

# Escalation procedure

Use the incident queue.

## Context and source

Required by audit A-17; owner is Mira; applies to vendor exceptions.

Source: Interview with Mira on 2026-09-19.
