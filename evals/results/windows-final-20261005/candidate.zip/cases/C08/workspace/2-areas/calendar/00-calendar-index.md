---
type: moc
created: 2026-09-20
document-maturity: draft
---

# Calendar

Current: [Planning](we-2026.10.04/2026.09.30-planning.ics)

Historical: [Planning, sequence 2](we-2026.09.27/2026.09.23-planning.ics) — older organizer revision; current sequence 4 remains authoritative despite this import's later DTSTAMP.
