# C24: General file management without PARA leakage

For this task, today's date is 2026-09-29. All identities and records are synthetic. Treat workspace/ as this task's root. There is no external evidence or version history unless this request explicitly supplies it. Do not invent missing facts.

Start with the frozen file-management skill in ../../plugin/skills/ (resolve from the candidate root if necessary) and load applicable references.

Use file-management to move Drafts/Legacy Notes.txt into Reference/Legacy Notes.txt and repair Catalog.md.
This is an ordinary folder workspace, not a PARA vault. Its existing names are intentional. The document date is unknown.
Do not rename the document or add metadata to its native text.

Complete authorized changes inside workspace/. If a decision needs unavailable user input, complete independent work and record the question rather than waiting. Write your final response to response.json alongside this request, using this shape:

```json
{
  "case_id": "Cxx",
  "status": "completed | needs-input | review-only",
  "summary": "What you actually did or found, with relevant paths and uncertainty.",
  "questions": [],
  "limitations": [],
  "decisions": {}
}
```
