---
type: note
created: 2026-09-29
status: draft
---

# Mobile accessibility request

Customer Rowan needs keyboard navigation on mobile.
