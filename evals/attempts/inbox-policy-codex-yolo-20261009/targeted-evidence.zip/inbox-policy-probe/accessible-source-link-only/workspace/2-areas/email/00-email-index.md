---
type: moc
created: 2026-09-20
document-maturity: draft
---

# Email

Correspondence.

- [Budget approval](https://mail.example.test/messages/budget-approval-29) — Native source identifier: budget-approval-29; native email remains the master for live state. Reachability supplied by the task.
