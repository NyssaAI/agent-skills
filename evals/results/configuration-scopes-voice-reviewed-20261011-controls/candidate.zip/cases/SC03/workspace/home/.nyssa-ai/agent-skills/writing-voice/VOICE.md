# Writing voice

## Scope
User defaults for all projects. Synthetic home: home. Private local storage accepted; no sharing, synchronization, or packaging.

## Explicit preferences
- Prefer direct requests.

## Evidence and confidence
Direct user instruction, 2026-09-29. No inferred voice habits or examples are established.
