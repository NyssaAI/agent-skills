---
type: moc
created: 2026-09-20
status: draft
---

# Calendar

Meetings.

[Weekly planning series](we-2026.09.27/2026.09.21-planning-series.ics) ? native recurring series starting September 21.

[September 29 exception](we-2026.10.04/2026.09.29-planning-exception.ics) ? rescheduled occurrence with RECURRENCE-ID September 28.
