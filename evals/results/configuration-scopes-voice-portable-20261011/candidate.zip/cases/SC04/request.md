# SC04: Malformed project is diagnostic

For this task, today's date is 2026-09-29. All identities and records are synthetic. Treat workspace/ as this task's root. There is no external evidence or version history unless this request explicitly supplies it. Do not invent missing facts.

Start with the frozen write-in-user-voice skill in ../../plugin/skills/ (resolve from the candidate root if necessary) and load applicable references.

Verified home is home and root project-a. Project writing-voice exists but lacks VOICE. Draft project-a/message.md asking Rowan to review by Friday from supplied facts, and disclose the incomplete selected bundle. Do not silently fall back or save profiles.

Complete authorized changes inside workspace/. If a decision needs unavailable user input, complete independent work and record the question rather than waiting. Write your final response to response.json alongside this request, using this shape:

```json
{
  "case_id": "Cxx",
  "status": "completed | needs-input | review-only",
  "summary": "What you actually did or found, with relevant paths and uncertainty.",
  "questions": [],
  "limitations": [],
  "decisions": {}
}
```
