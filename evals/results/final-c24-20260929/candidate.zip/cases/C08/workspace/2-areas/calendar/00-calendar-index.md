---
type: moc
created: 2026-09-20
status: draft
---

# Calendar

Current: [Planning](we-2026.10.04/2026.09.30-planning.ics)

Historical: [Planning, sequence 2](we-2026.09.27/2026.09.23-planning.ics) � older invitation; current sequence 4 remains linked above.

