# Writing voice

## Scope
This project. Sparse evidence from two user-authored lines; no general voice match is established.

## Explicit preferences
- Use contractions.
- Do not use exclamation marks.
- Use plain words.

## Evidence and confidence
Explicit approved preferences from the user, 2026-09-29. The two AUTHOR lines in samples/mine.txt are limited evidence; their punctuation does not override the explicit preferences. Quoted third-party material is excluded. No sample excerpts retained.
