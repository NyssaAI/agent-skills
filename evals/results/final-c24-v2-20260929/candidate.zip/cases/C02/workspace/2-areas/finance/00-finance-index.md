---
type: moc
created: 2026-09-20
status: draft
---

# Finance

Ongoing payroll operations.

## Projects

[[1-projects/2026.09.29-payroll-migration/2026.09.29-payroll-migration-index|Payroll migration]] ? migrate payroll processing to the new provider.
