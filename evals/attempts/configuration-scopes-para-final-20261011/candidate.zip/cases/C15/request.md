# C15: Reactivate native record and companion

For this task, today's date is 2026-09-29. All identities and records are synthetic. Treat workspace/ as this task's root. There is no external evidence or version history unless this request explicitly supplies it. Do not invent missing facts.

Start with the frozen manage-vault-lifecycle skill in ../../plugin/skills/ (resolve from the candidate root if necessary) and load applicable references.

Return the archived native record.txt to active use at 2-areas/finance/record.txt.
It was an operational record, not a historical snapshot. Preserve its history and companion navigation.
Update the finance index.

Complete authorized changes inside workspace/. If a decision needs unavailable user input, complete independent work and record the question rather than waiting. Write your final response to response.json alongside this request, using this shape:

```json
{
  "case_id": "Cxx",
  "status": "completed | needs-input | review-only",
  "summary": "What you actually did or found, with relevant paths and uncertainty.",
  "questions": [],
  "limitations": [],
  "decisions": {}
}
```
