---
type: moc
created: 2026-09-20
document-maturity: draft
---

# Finance

Procedures.

- [[2-areas/finance/escalation-procedure|Escalation procedure]] — vendor exceptions required by audit A-17; owner Mira.
