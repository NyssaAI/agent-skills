# Writing voice

## Scope
User default for all projects; only the explicit preference below is established.

## Explicit preferences
- Prefer direct requests.

## Evidence and confidence
Source: direct user request, 2026-09-29. Explicitly approved; no inferred habits or retained examples.
