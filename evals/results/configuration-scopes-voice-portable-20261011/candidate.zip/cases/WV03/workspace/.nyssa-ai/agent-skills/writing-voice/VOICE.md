# Synthetic voice profile

Approved preferences: plain words, contractions, no exclamation marks.
Email mode: greeting and a clear next step, short paragraphs.
Chat mode: one or two direct sentences; omit greetings.
Evidence: synthetic approved examples only; no claims about personal beliefs.

## Explicit preference update
- Prefer direct requests over rhetorical questions.
  Source: exact user instruction and approved stylistic correction in edits.md, 2026-09-29. The record count and delivery date corrections are factual and are not voice rules.
