Use frozen-plugin-builder for B01 through B04.
Each request explicitly scopes a separate synthetic task; do not expand component
tests into full releases. Read only this candidate directory and host tools, never
the control directory or grader. Write only the case workspaces, response.json,
and B04/execution.json beside the requests. Do not contact external services,
install hosts, or push.
Load details only as needed. B04 alone exercises the independent named agents;
all other cases are single-agent tasks. Keep scratch inside workspace/.temp/.
