# C17: Explicitly approved protected revision and metadata migration

For this task, today's date is 2026-09-29. All identities and records are synthetic. Treat workspace/ as this task's root. There is no external evidence or version history unless this request explicitly supplies it. Do not invent missing facts.

Start with the frozen para-vault skill in ../../plugin/skills/ (resolve from the candidate root if necessary) and load applicable references.

I approve and accept as reliable this specific revision to approval-policy.md:
replace 'Two reviewers must approve every release.' with 'One reviewer must approve every release.'
Apply it at the current policy path, preserving its authority and recoverable accepted history.
Also migrate this policy's legacy status field to document-maturity, keeping its current maturity and task-state.
No version-control history is available in this fixture. Do not ask me to approve this same change again.

Complete authorized changes inside workspace/. If a decision needs unavailable user input, complete independent work and record the question rather than waiting. Write your final response to response.json alongside this request, using this shape:

```json
{
  "case_id": "Cxx",
  "status": "completed | needs-input | review-only",
  "summary": "What you actually did or found, with relevant paths and uncertainty.",
  "questions": [],
  "limitations": [],
  "decisions": {}
}
```
