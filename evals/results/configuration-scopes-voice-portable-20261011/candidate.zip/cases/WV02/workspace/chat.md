Please review the pilot draft by Friday. We've got 12 participants, the draft is due October 14, and launch timing is uncertain.
