# WV02: Modes, house style, and read-only application

For this task, today's date is 2026-09-29. All identities and records are synthetic. Treat workspace/ as this task's root. There is no external evidence or version history unless this request explicitly supplies it. Do not invent missing facts.

Start with the frozen write-in-user-voice skill in ../../plugin/skills/ (resolve from the candidate root if necessary) and load applicable references.

Draft an email and a chat message as me using the existing profile.
Facts for both: the pilot has 12 participants; the draft is due October 14; launch timing is uncertain; ask Rowan to review by Friday. No launch commitment is authorized.
For the email the destination requires the heading 'Pilot update', no contractions, and a greeting. The chat has no such house style requirement.
Save email.md and chat.md at the workspace root. This task only drafts; do not update the profile or its examples.

Complete authorized changes inside workspace/. If a decision needs unavailable user input, complete independent work and record the question rather than waiting. Write your final response to response.json alongside this request, using this shape:

```json
{
  "case_id": "Cxx",
  "status": "completed | needs-input | review-only",
  "summary": "What you actually did or found, with relevant paths and uncertainty.",
  "questions": [],
  "limitations": [],
  "decisions": {}
}
```
