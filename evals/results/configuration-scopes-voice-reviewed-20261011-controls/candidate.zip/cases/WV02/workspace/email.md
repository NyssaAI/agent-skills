Pilot update

Hi Rowan,

The pilot has 12 participants. The draft is due October 14, and launch timing is uncertain.

Please review by Friday.
