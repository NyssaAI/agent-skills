---
type: note
created: 2026-10-08
document-maturity: raw
---
# Meeting practice
Keep an agenda and record decisions. This supports the ongoing meetings responsibility.
