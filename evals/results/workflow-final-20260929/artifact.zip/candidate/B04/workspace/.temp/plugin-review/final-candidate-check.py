﻿import hashlib, json
from pathlib import Path
root = Path(r'D:\repos\NyssaAI\skills\.temp\evals-builder\workflow-final-20260929\candidate\B04\workspace')
baseline = json.loads((root/'.temp/baseline-hashes.json').read_text())
claimed = json.loads((root/'.temp/candidate-hashes.json').read_text())
def sha(data): return hashlib.sha256(data).hexdigest()
actual = {p: sha((root/p).read_bytes()) for p in baseline}
core = (root/'skills/sample-notes/core.md').read_bytes()
startup = (root/'AGENTS.md').read_bytes()
assert startup.count(core) == 1
assert startup.endswith(core)
assert sha(startup[:-len(core)]) == baseline['AGENTS.md']
assert b'Keep user notes private.' in startup
unchanged = ['skills/sample-notes/SKILL.md','skills/sample-notes/core.md','evals/case.md','notes/keep.txt']
assert all(actual[p] == baseline[p] for p in unchanged)
for p in ['plugin.json','.claude-plugin/plugin.json']:
    raw = (root/p).read_bytes()
    data = json.loads(raw)
    assert data['version'] == '0.2.0'
    assert raw.count(b'0.2.0') == 1
    assert sha(raw.replace(b'0.2.0', b'0.1.0')) == baseline[p]
assert actual == claimed
assert not (root/'evals/result.json').exists()
assert not (root/'.temp/probe.txt').exists()
result = {'hashes':actual,'checks':{'exact_core_body_once':True,'original_startup_bytes_preserved_by_baseline_hash':True,'both_manifests_only_version_delta':True,'unchanged_inputs_match_baseline':True,'candidate_hash_claims_match':True,'no_behavioral_output_yet':True}}
(root/'.temp/plugin-review/final-candidate-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
