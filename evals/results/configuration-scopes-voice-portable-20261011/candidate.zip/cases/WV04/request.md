# WV04: Useful drafting without a profile

For this task, today's date is 2026-09-29. All identities and records are synthetic. Treat workspace/ as this task's root. There is no external evidence or version history unless this request explicitly supplies it. Do not invent missing facts.

Start with the frozen write-in-user-voice skill in ../../plugin/skills/ (resolve from the candidate root if necessary) and load applicable references.

Write a short message as me asking Rowan to review the pilot draft by Friday. The pilot has 12 participants and launch timing is uncertain.
No writing profile or samples are available in this established non-Git working root. Save message.md and complete useful drafting now; do not create a profile without a setup request.

Complete authorized changes inside workspace/. If a decision needs unavailable user input, complete independent work and record the question rather than waiting. Write your final response to response.json alongside this request, using this shape:

```json
{
  "case_id": "Cxx",
  "status": "completed | needs-input | review-only",
  "summary": "What you actually did or found, with relevant paths and uncertainty.",
  "questions": [],
  "limitations": [],
  "decisions": {}
}
```
