---
type: moc
created: 2026-09-20
status: draft
---

# Finance

[Procedure, now owned by site launch](../../1-projects/2026.09.10-site-launch/discovery/procedure.md#evidence)
